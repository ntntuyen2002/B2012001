<!DOCTYPE HTML>
<html>  
<body>

<h1>Sửa mật khẩu</h1>
<form action="sua_mk.php" method="post">
Mật khẩu cũ: <input type="password" name="oldpass" id="oldpass"><br>
Mật khẩu mới: <input type="password" name="newpass" id="newpass"><br>
Nhập lại mật khẩu mới: <input type="password" name="renewpass" id="renewpass"><br>

<input type="submit">
</form>

